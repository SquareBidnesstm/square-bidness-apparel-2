import { 
  User, InsertUser, 
  Product, InsertProduct, 
  Cart, InsertCart, 
  CartItem, InsertCartItem,
  Order, InsertOrder,
  OrderItem, InsertOrderItem,
  Favorite, InsertFavorite,
  users,
  products,
  carts,
  cartItems,
  orders,
  orderItems,
  favorites
} from "@shared/schema";
import { drizzle } from "drizzle-orm/postgres-js";
import { eq, or, sql } from "drizzle-orm";
import { Pool } from "pg";
import type { PostgresJsDatabase } from "drizzle-orm/postgres-js";

export interface IStorage {
  // User Operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product Operations
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getProductsBySubcategory(subcategory: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart Operations
  getCart(cartId: number): Promise<Cart | undefined>;
  getCartBySessionId(sessionId: string): Promise<Cart | undefined>;
  createCart(cart: InsertCart): Promise<Cart>;
  
  // Cart Item Operations
  getCartItems(cartId: number): Promise<CartItem[]>;
  addCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  removeCartItem(id: number): Promise<boolean>;
  clearCart(cartId: number): Promise<boolean>;
  
  // Order Operations
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  getUserOrders(userId: number): Promise<Order[]>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Order Item Operations
  addOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  
  // Favorites Operations
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, productId: number): Promise<boolean>;
  getUserFavorites(userId: number): Promise<Favorite[]>;
  isFavorite(userId: number, productId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private products: Map<number, Product>;
  private carts: Map<number, Cart>;
  private cartItems: Map<number, CartItem>;
  
  private userId: number;
  private productId: number;
  private cartId: number;
  private cartItemId: number;
  
  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.carts = new Map();
    this.cartItems = new Map();
    
    this.userId = 1;
    this.productId = 1;
    this.cartId = 1;
    this.cartItemId = 1;
    
    // Initialize with sample products
    this.initializeProducts();
  }
  
  // User Operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }
  
  // Product Operations
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.category === category
    );
  }
  
  async getProductsBySubcategory(subcategory: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.subcategory === subcategory
    );
  }
  
  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      (product) => product.featured
    );
  }
  
  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) => 
        product.name.toLowerCase().includes(lowercaseQuery) ||
        product.description.toLowerCase().includes(lowercaseQuery) ||
        product.category.toLowerCase().includes(lowercaseQuery) ||
        product.subcategory.toLowerCase().includes(lowercaseQuery)
    );
  }
  
  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productId++;
    // Ensure all fields have default values if not provided
    const newProduct: Product = {
      ...product,
      id,
      featured: product.featured ?? false,
      new: product.new ?? false,
      trending: product.trending ?? false,
      bestseller: product.bestseller ?? false,
      hot: product.hot ?? false,
      rating: product.rating ?? 0,
      reviewCount: product.reviewCount ?? 0
    };
    this.products.set(id, newProduct);
    return newProduct;
  }
  
  // Cart Operations
  async getCart(cartId: number): Promise<Cart | undefined> {
    return this.carts.get(cartId);
  }
  
  async getCartBySessionId(sessionId: string): Promise<Cart | undefined> {
    return Array.from(this.carts.values()).find(
      (cart) => cart.sessionId === sessionId
    );
  }
  
  async createCart(cart: InsertCart): Promise<Cart> {
    const id = this.cartId++;
    const newCart: Cart = { 
      ...cart, 
      id,
      sessionId: cart.sessionId || null,
      userId: cart.userId || null
    };
    this.carts.set(id, newCart);
    return newCart;
  }
  
  // Cart Item Operations
  async getCartItems(cartId: number): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(
      (item) => item.cartId === cartId
    );
  }
  
  async addCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemId++;
    const newCartItem: CartItem = { 
      ...cartItem, 
      id,
      quantity: cartItem.quantity || 1
    };
    this.cartItems.set(id, newCartItem);
    return newCartItem;
  }
  
  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem: CartItem = { ...cartItem, quantity };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }
  
  async removeCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }
  
  async clearCart(cartId: number): Promise<boolean> {
    const cartItems = await this.getCartItems(cartId);
    cartItems.forEach(item => this.cartItems.delete(item.id));
    return true;
  }

  // Initialize sample products
  private initializeProducts() {
    const mensProducts = [
      {
        id: this.productId++,
        name: "Premium Urban Hoodie",
        description: "Stay comfortable and stylish with our Premium Urban Hoodie. Crafted from high-quality cotton blend fabric that's both soft and durable. Features the iconic Square Bidness logo and our signature urban design elements.",
        price: 59.99,
        category: "men",
        subcategory: "hoodies",
        image: "https://images.unsplash.com/photo-1578681994506-b8f463449011?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1578681994506-b8f463449011?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
          "https://images.unsplash.com/photo-1613852348851-df1739db8201?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
          "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: true,
        new: true,
        trending: false,
        bestseller: false,
        hot: false,
        colors: ["black", "gray", "red", "blue"],
        sizes: ["S", "M", "L", "XL", "XXL"],
        stock: 100,
        rating: 4.5,
        reviewCount: 124
      },
      {
        id: this.productId++,
        name: "Urban Graphic Tee",
        description: "Express your style with our Urban Graphic Tee featuring unique Square Bidness designs. Made from 100% cotton for maximum comfort and breathability.",
        price: 34.99,
        category: "men",
        subcategory: "t-shirts",
        image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
          "https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: true,
        new: false,
        trending: false,
        bestseller: false,
        hot: true,
        colors: ["white", "black", "gray"],
        sizes: ["S", "M", "L", "XL", "XXL"],
        stock: 150,
        rating: 4.2,
        reviewCount: 85
      },
      {
        id: this.productId++,
        name: "Designer Denim Jeans",
        description: "Our Designer Denim Jeans combine style and comfort with premium quality denim fabric. Features the Square Bidness signature back pocket design.",
        price: 79.99,
        category: "men",
        subcategory: "jeans",
        image: "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: false,
        trending: true,
        bestseller: false,
        hot: false,
        colors: ["blue", "black", "gray"],
        sizes: ["30", "32", "34", "36", "38"],
        stock: 75,
        rating: 4.7,
        reviewCount: 53
      },
      {
        id: this.productId++,
        name: "Urban Streetwear Cap",
        description: "Complete your look with our Urban Streetwear Cap. Features embroidered Square Bidness logo and adjustable strap for perfect fit.",
        price: 29.99,
        category: "men",
        subcategory: "accessories",
        image: "https://images.unsplash.com/photo-1624623278313-a930126a11c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1624623278313-a930126a11c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: false,
        trending: false,
        bestseller: true,
        hot: false,
        colors: ["black", "white", "red"],
        sizes: ["One Size"],
        stock: 200,
        rating: 4.4,
        reviewCount: 68
      }
    ];
    
    const womensProducts = [
      {
        id: this.productId++,
        name: "Elegant Evening Dress",
        description: "Make a statement with our Elegant Evening Dress. Features a modern cut and premium fabric that drapes beautifully for a sophisticated look.",
        price: 89.99,
        category: "women",
        subcategory: "dresses",
        image: "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
          "https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: true,
        new: false,
        trending: true,
        bestseller: false,
        hot: false,
        colors: ["black", "purple", "blue"],
        sizes: ["XS", "S", "M", "L", "XL"],
        stock: 50,
        rating: 4.8,
        reviewCount: 92
      },
      {
        id: this.productId++,
        name: "Designer Blouse",
        description: "Our Designer Blouse combines elegance with comfort. Made from lightweight, breathable fabric with unique Square Bidness design elements.",
        price: 49.99,
        category: "women",
        subcategory: "tops",
        image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: true,
        trending: false,
        bestseller: false,
        hot: false,
        colors: ["white", "black", "red", "blue"],
        sizes: ["XS", "S", "M", "L", "XL"],
        stock: 120,
        rating: 4.3,
        reviewCount: 76
      },
      {
        id: this.productId++,
        name: "Premium Denim Skirt",
        description: "Our Premium Denim Skirt offers versatile style for any occasion. Features high-quality denim with the perfect amount of stretch for comfort.",
        price: 54.99,
        category: "women",
        subcategory: "bottoms",
        image: "https://images.unsplash.com/photo-1551489186-cf8726f514f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1551489186-cf8726f514f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: false,
        trending: true,
        bestseller: false,
        hot: false,
        colors: ["blue", "black", "white"],
        sizes: ["XS", "S", "M", "L", "XL"],
        stock: 85,
        rating: 4.5,
        reviewCount: 64
      },
      {
        id: this.productId++,
        name: "Designer Handbag",
        description: "Complete your outfit with our Designer Handbag. Features premium materials, ample storage, and the iconic Square Bidness emblem.",
        price: 79.99,
        category: "women",
        subcategory: "accessories",
        image: "https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: false,
        trending: false,
        bestseller: true,
        hot: false,
        colors: ["black", "brown", "red"],
        sizes: ["One Size"],
        stock: 60,
        rating: 4.6,
        reviewCount: 47
      }
    ];
    
    const kidsProducts = [
      {
        id: this.productId++,
        name: "Cool Kids Casual Set",
        description: "Our Cool Kids Casual Set combines style and comfort for active kids. Includes matching top and bottom in durable, easy-care fabric.",
        price: 45.99,
        category: "kids",
        subcategory: "boys",
        image: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
          "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: true,
        new: false,
        trending: false,
        bestseller: true,
        hot: false,
        colors: ["blue", "green", "yellow"],
        sizes: ["3T", "4T", "5", "6", "7"],
        stock: 100,
        rating: 4.7,
        reviewCount: 112
      },
      {
        id: this.productId++,
        name: "Girls' Party Dress",
        description: "Our Girls' Party Dress is perfect for special occasions. Features adorable design details and comfortable fabric that allows for easy movement.",
        price: 39.99,
        category: "kids",
        subcategory: "girls",
        image: "https://images.unsplash.com/photo-1476234251651-f353703a034d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1476234251651-f353703a034d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: true,
        trending: false,
        bestseller: false,
        hot: false,
        colors: ["pink", "purple", "white"],
        sizes: ["3T", "4T", "5", "6", "7"],
        stock: 75,
        rating: 4.6,
        reviewCount: 58
      },
      {
        id: this.productId++,
        name: "Infant Onesie Set",
        description: "Our Infant Onesie Set includes 3 adorable designs made from 100% organic cotton. Perfect for sensitive skin and everyday comfort.",
        price: 32.99,
        category: "kids",
        subcategory: "infants",
        image: "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        images: [
          "https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
        ],
        featured: false,
        new: false,
        trending: true,
        bestseller: false,
        hot: false,
        colors: ["multicolor"],
        sizes: ["0-3M", "3-6M", "6-9M", "9-12M"],
        stock: 120,
        rating: 4.9,
        reviewCount: 87
      }
    ];
    
    [...mensProducts, ...womensProducts, ...kidsProducts].forEach(product => {
      this.products.set(product.id, product as Product);
    });
  }
}

// Database Storage Implementation using PostgreSQL
export class DbStorage implements IStorage {
  private db: PostgresJsDatabase;

  constructor() {
    // Initialize database connection
    const connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error("DATABASE_URL environment variable is not set");
    }
    
    const client = new Pool({
      connectionString,
    });
    
    this.db = drizzle(client);
    console.log("Connected to PostgreSQL database");
  }

  // User Operations
  async getUser(id: number): Promise<User | undefined> {
    const results = await this.db.select().from(users).where(eq(users.id, id));
    return results[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await this.db.select().from(users).where(eq(users.username, username));
    return results[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const results = await this.db.insert(users).values(user).returning();
    return results[0];
  }

  // Product Operations
  async getProducts(): Promise<Product[]> {
    return await this.db.select().from(products);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const results = await this.db.select().from(products).where(eq(products.id, id));
    return results[0];
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return await this.db.select().from(products).where(eq(products.category, category));
  }

  async getProductsBySubcategory(subcategory: string): Promise<Product[]> {
    return await this.db.select().from(products).where(eq(products.subcategory, subcategory));
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return await this.db.select().from(products).where(eq(products.featured, true));
  }

  async searchProducts(query: string): Promise<Product[]> {
    // Basic search on name and description
    const lowerQuery = query.toLowerCase();
    return await this.db.select().from(products).where(
      or(
        sql`lower(${products.name}) like ${`%${lowerQuery}%`}`,
        sql`lower(${products.description}) like ${`%${lowerQuery}%`}`
      )
    );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const results = await this.db.insert(products).values(product).returning();
    return results[0];
  }

  // Cart Operations
  async getCart(cartId: number): Promise<Cart | undefined> {
    const results = await this.db.select().from(carts).where(eq(carts.id, cartId));
    return results[0];
  }

  async getCartBySessionId(sessionId: string): Promise<Cart | undefined> {
    const results = await this.db.select().from(carts).where(eq(carts.sessionId, sessionId));
    return results[0];
  }

  async createCart(cart: InsertCart): Promise<Cart> {
    const results = await this.db.insert(carts).values(cart).returning();
    return results[0];
  }

  // Cart Item Operations
  async getCartItems(cartId: number): Promise<CartItem[]> {
    return await this.db.select().from(cartItems).where(eq(cartItems.cartId, cartId));
  }

  async addCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const results = await this.db.insert(cartItems).values(cartItem).returning();
    return results[0];
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const results = await this.db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return results[0];
  }

  async removeCartItem(id: number): Promise<boolean> {
    const result = await this.db
      .delete(cartItems)
      .where(eq(cartItems.id, id));
    return true;
  }

  async clearCart(cartId: number): Promise<boolean> {
    await this.db
      .delete(cartItems)
      .where(eq(cartItems.cartId, cartId));
    return true;
  }
}

// Now that we have the database properly set up, let's use PostgreSQL in production
export const storage = process.env.NODE_ENV === 'production' 
  ? new DbStorage() 
  : new MemStorage();
