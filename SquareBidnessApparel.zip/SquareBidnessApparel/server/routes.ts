import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertCartItemSchema, insertUserSchema } from "@shared/schema";
import crypto from "crypto";
import Stripe from "stripe";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Middleware to verify JWT token
const authenticateToken = (req: any, res: Response, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const api = express.Router();
  app.use("/api", api);

  // Authentication Routes
  
  // Register new user
  api.post("/auth/register", async (req: Request, res: Response) => {
    try {
      const validationResult = insertUserSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ message: "Invalid input data" });
      }

      const { username, email, password, name } = validationResult.data;

      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name
      });

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        message: "User created successfully",
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name
        }
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  // Login user
  api.post("/auth/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, username: user.username },
        JWT_SECRET,
        { expiresIn: '7d' }
      );

      res.json({
        message: "Login successful",
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Get current user
  api.get("/auth/me", authenticateToken, async (req: any, res: Response) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Get all products
  api.get("/products", async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get product by ID
  api.get("/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      const product = await storage.getProductById(id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }

      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Get products by category
  api.get("/products/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products by category" });
    }
  });

  // Get products by subcategory
  api.get("/products/subcategory/:subcategory", async (req: Request, res: Response) => {
    try {
      const { subcategory } = req.params;
      const products = await storage.getProductsBySubcategory(subcategory);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products by subcategory" });
    }
  });

  // Get featured products
  api.get("/products/featured", async (req: Request, res: Response) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured products" });
    }
  });

  // Search products
  api.get("/products/search/:query", async (req: Request, res: Response) => {
    try {
      const { query } = req.params;
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to search products" });
    }
  });

  // Get or create cart
  api.get("/cart", async (req: Request, res: Response) => {
    try {
      // Check if session has a cart
      let sessionId = req.cookies?.sessionId;
      
      // If no session ID, create one
      if (!sessionId) {
        sessionId = crypto.randomBytes(16).toString("hex");
        res.cookie("sessionId", sessionId, { 
          httpOnly: true, 
          maxAge: 7 * 24 * 60 * 60 * 1000 // 1 week
        });
      }
      
      // Try to get existing cart
      let cart = await storage.getCartBySessionId(sessionId);
      
      // If no cart exists, create one
      if (!cart) {
        cart = await storage.createCart({
          userId: null,
          sessionId,
          createdAt: new Date().toISOString()
        });
      }
      
      // Get cart items
      const cartItems = await storage.getCartItems(cart.id);
      
      // Get product details for each cart item
      const cartItemsWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProductById(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json({
        cart,
        items: cartItemsWithProducts
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get cart" });
    }
  });

  // Add item to cart
  api.post("/cart/items", async (req: Request, res: Response) => {
    try {
      // Validate request
      const validationResult = insertCartItemSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: "Invalid cart item data" });
      }
      
      // Get sessionId from cookie
      let sessionId = req.cookies?.sessionId;
      
      // If no session ID, create one
      if (!sessionId) {
        sessionId = crypto.randomBytes(16).toString("hex");
        res.cookie("sessionId", sessionId, { 
          httpOnly: true, 
          maxAge: 7 * 24 * 60 * 60 * 1000 // 1 week
        });
      }
      
      // Try to get existing cart
      let cart = await storage.getCartBySessionId(sessionId);
      
      // If no cart exists, create one
      if (!cart) {
        cart = await storage.createCart({
          userId: null,
          sessionId,
          createdAt: new Date().toISOString()
        });
      }
      
      // Check if product exists
      const product = await storage.getProductById(validationResult.data.productId);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      
      // Add item to cart
      const cartItem = await storage.addCartItem({
        ...validationResult.data,
        cartId: cart.id
      });
      
      // Get updated cart
      const cartItems = await storage.getCartItems(cart.id);
      const cartItemsWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProductById(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json({
        cart,
        items: cartItemsWithProducts
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to add item to cart" });
    }
  });

  // Update cart item quantity
  api.patch("/cart/items/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid cart item ID" });
      }
      
      const quantitySchema = z.object({
        quantity: z.number().min(1).max(99)
      });
      
      // Validate request
      const validationResult = quantitySchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ message: "Invalid quantity" });
      }
      
      // Update cart item
      const updatedCartItem = await storage.updateCartItemQuantity(id, validationResult.data.quantity);
      if (!updatedCartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Get updated cart
      const cart = await storage.getCart(updatedCartItem.cartId);
      const cartItems = await storage.getCartItems(updatedCartItem.cartId);
      const cartItemsWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProductById(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json({
        cart,
        items: cartItemsWithProducts
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to update cart item" });
    }
  });

  // Remove item from cart
  api.delete("/cart/items/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid cart item ID" });
      }
      
      // Get cart item first to get the cart ID
      const cartItems = await storage.getCartItems(0); // Pass a dummy ID to get all cart items
      const cartItem = cartItems.find(item => item.id === id);
      
      if (!cartItem) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Remove cart item
      const removed = await storage.removeCartItem(id);
      if (!removed) {
        return res.status(404).json({ message: "Cart item not found" });
      }
      
      // Get updated cart
      const cart = await storage.getCart(cartItem.cartId);
      const updatedCartItems = await storage.getCartItems(cartItem.cartId);
      const cartItemsWithProducts = await Promise.all(
        updatedCartItems.map(async (item) => {
          const product = await storage.getProductById(item.productId);
          return {
            ...item,
            product
          };
        })
      );
      
      res.json({
        cart,
        items: cartItemsWithProducts
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove item from cart" });
    }
  });

  // Clear cart
  api.delete("/cart", async (req: Request, res: Response) => {
    try {
      // Get sessionId from cookie
      const sessionId = req.cookies?.sessionId;
      
      if (!sessionId) {
        return res.status(400).json({ message: "No cart found" });
      }
      
      // Try to get existing cart
      const cart = await storage.getCartBySessionId(sessionId);
      
      if (!cart) {
        return res.status(404).json({ message: "Cart not found" });
      }
      
      // Clear cart
      await storage.clearCart(cart.id);
      
      res.json({
        cart,
        items: []
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear cart" });
    }
  });
  
  // Create Payment Intent for Stripe checkout
  api.post("/create-payment-intent", async (req: Request, res: Response) => {
    try {
      // Get sessionId from cookie
      const sessionId = req.cookies?.sessionId;
      
      if (!sessionId) {
        return res.status(400).json({ message: "No cart found" });
      }
      
      // Try to get existing cart
      const cart = await storage.getCartBySessionId(sessionId);
      
      if (!cart) {
        return res.status(404).json({ message: "Cart not found" });
      }
      
      // Get cart items
      const cartItems = await storage.getCartItems(cart.id);
      
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }
      
      // Calculate total amount
      let totalAmount = 0;
      for (const item of cartItems) {
        const product = await storage.getProductById(item.productId);
        if (product) {
          totalAmount += product.price * item.quantity;
        }
      }
      
      // Create a payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(totalAmount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          cartId: cart.id.toString(),
          sessionId
        },
      });
      
      // Return the client secret
      res.json({
        clientSecret: paymentIntent.client_secret,
        amount: totalAmount
      });
    } catch (error: any) {
      console.error("Payment intent error:", error);
      res.status(500).json({ message: "Failed to create payment intent", error: error.message });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
