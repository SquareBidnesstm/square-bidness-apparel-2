// Product Types
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string; // men, women, kids
  subcategory: string; // t-shirts, hoodies, jeans, etc.
  image: string;
  images: string[];
  featured: boolean;
  new: boolean;
  trending: boolean;
  bestseller: boolean;
  hot: boolean;
  colors: string[];
  sizes: string[];
  stock: number;
  rating: number;
  reviewCount: number;
}

// User Types
export interface User {
  id: number;
  username: string;
  email: string;
  name: string;
}

// Cart Types
export interface Cart {
  id: number;
  userId: number | null;
  sessionId: string;
  createdAt: string;
}

export interface CartItem {
  id: number;
  cartId: number;
  productId: number;
  quantity: number;
  color: string;
  size: string;
}

// Category Types
export interface Category {
  id: string;
  name: string;
  slug: string;
  subcategories: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  categoryId: string;
  image: string;
}

// Common UI Types
export interface MenuItem {
  label: string;
  href: string;
  children?: MenuItem[];
}

export interface StoreDisplayItem {
  title: string;
  description: string;
  image: string;
  buttonText: string;
  buttonLink: string;
}

export type ColorVariant = 
  | 'black'
  | 'white'
  | 'red'
  | 'blue'
  | 'gray'
  | 'green'
  | 'purple'
  | 'yellow'
  | 'pink'
  | 'brown'
  | 'multicolor';

export type SizeVariant = 
  | 'XS'
  | 'S'
  | 'M'
  | 'L'
  | 'XL'
  | 'XXL'
  | '0-3M'
  | '3-6M'
  | '6-9M'
  | '9-12M'
  | '3T'
  | '4T'
  | '5'
  | '6'
  | '7'
  | '30'
  | '32'
  | '34'
  | '36'
  | '38'
  | 'One Size';

// Form Types
export interface NewsletterFormData {
  email: string;
}

export interface SearchFormData {
  query: string;
}

// State Types
export interface CartState {
  items: CartItem[];
  isOpen: boolean;
}

export interface FilterState {
  priceRange: [number, number];
  colors: string[];
  sizes: string[];
  sortBy: 'newest' | 'price-low' | 'price-high' | 'rating';
}
