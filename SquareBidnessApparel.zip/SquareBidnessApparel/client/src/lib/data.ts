import { Product, Category, Subcategory, StoreDisplayItem } from './types';

/**
 * Category and subcategory data for navigation and category pages
 */
export const categories: Category[] = [
  {
    id: 'men',
    name: "MEN'S COLLECTION",
    slug: 'men',
    subcategories: [
      {
        id: 'men-tshirts',
        name: 'T-SHIRTS',
        slug: 't-shirts',
        categoryId: 'men',
        image: 'https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'men-hoodies',
        name: 'HOODIES',
        slug: 'hoodies',
        categoryId: 'men',
        image: 'https://images.unsplash.com/photo-1613852348851-df1739db8201?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'men-jeans',
        name: 'JEANS',
        slug: 'jeans',
        categoryId: 'men',
        image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'men-accessories',
        name: 'ACCESSORIES',
        slug: 'accessories',
        categoryId: 'men',
        image: 'https://images.unsplash.com/photo-1624623278313-a930126a11c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      }
    ]
  },
  {
    id: 'women',
    name: "WOMEN'S COLLECTION",
    slug: 'women',
    subcategories: [
      {
        id: 'women-dresses',
        name: 'DRESSES',
        slug: 'dresses',
        categoryId: 'women',
        image: 'https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'women-tops',
        name: 'TOPS',
        slug: 'tops',
        categoryId: 'women',
        image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'women-bottoms',
        name: 'BOTTOMS',
        slug: 'bottoms',
        categoryId: 'women',
        image: 'https://images.unsplash.com/photo-1551489186-cf8726f514f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'women-accessories',
        name: 'ACCESSORIES',
        slug: 'accessories',
        categoryId: 'women',
        image: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      }
    ]
  },
  {
    id: 'kids',
    name: "KIDS' COLLECTION",
    slug: 'kids',
    subcategories: [
      {
        id: 'kids-boys',
        name: 'BOYS',
        slug: 'boys',
        categoryId: 'kids',
        image: 'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'kids-girls',
        name: 'GIRLS',
        slug: 'girls',
        categoryId: 'kids',
        image: 'https://images.unsplash.com/photo-1476234251651-f353703a034d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      },
      {
        id: 'kids-infants',
        name: 'INFANTS',
        slug: 'infants',
        categoryId: 'kids',
        image: 'https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
      }
    ]
  }
];

/**
 * Find a category by its slug
 */
export function getCategoryBySlug(slug: string): Category | undefined {
  return categories.find(category => category.slug === slug);
}

/**
 * Find a subcategory by its slug and parent category slug
 */
export function getSubcategoryBySlug(categorySlug: string, subcategorySlug: string): Subcategory | undefined {
  const category = getCategoryBySlug(categorySlug);
  if (!category) return undefined;
  
  return category.subcategories.find(subcategory => subcategory.slug === subcategorySlug);
}

/**
 * Store display items for homepage
 */
export const storeDisplays: StoreDisplayItem[] = [
  {
    title: 'PREMIUM QUALITY',
    description: 'Crafted with the finest materials for style and durability',
    image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=800',
    buttonText: 'DISCOVER',
    buttonLink: '/quality'
  },
  {
    title: 'UNIQUE DESIGNS',
    description: 'Express your individuality with our exclusive styles',
    image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=800',
    buttonText: 'EXPLORE',
    buttonLink: '/designs'
  }
];

/**
 * Get category descriptions
 */
export function getCategoryDescription(categorySlug: string): string {
  switch (categorySlug) {
    case 'men':
      return "Elevate your style with our premium men's apparel. From casual streetwear to sophisticated essentials.";
    case 'women':
      return "Discover our curated women's collection, designed for comfort, style, and self-expression.";
    case 'kids':
      return "Stylish, comfortable, and durable apparel for the little ones. Because they deserve to look good too.";
    case 'sale':
      return "Shop our sale collection for great deals on premium apparel. Limited time offers on select styles.";
    case 'new':
      return "Be the first to shop our latest arrivals. Stay ahead of the trends with our newest styles.";
    default:
      return "Discover premium quality clothing at Square Bidness. Express your unique style with our exclusive designs.";
  }
}

/**
 * Get subcategory descriptions
 */
export function getSubcategoryDescription(categorySlug: string, subcategorySlug: string): string {
  if (categorySlug === 'men') {
    switch (subcategorySlug) {
      case 't-shirts':
        return "Our premium men's t-shirts combine style and comfort with high-quality fabrics and unique designs.";
      case 'hoodies':
        return "Stay warm and stylish with our collection of men's hoodies, perfect for any casual occasion.";
      case 'jeans':
        return "Our men's jeans are crafted from premium denim for durability and style that lasts.";
      case 'accessories':
        return "Complete your look with our men's accessories, from caps to belts and everything in between.";
      default:
        return getCategoryDescription(categorySlug);
    }
  } else if (categorySlug === 'women') {
    switch (subcategorySlug) {
      case 'dresses':
        return "Find the perfect dress for any occasion in our collection of stylish and comfortable women's dresses.";
      case 'tops':
        return "Explore our women's tops collection, featuring versatile styles for any season or occasion.";
      case 'bottoms':
        return "From skirts to pants, our women's bottoms collection offers style and comfort for every day.";
      case 'accessories':
        return "Elevate any outfit with our women's accessories, including jewelry, bags, and more.";
      default:
        return getCategoryDescription(categorySlug);
    }
  } else if (categorySlug === 'kids') {
    switch (subcategorySlug) {
      case 'boys':
        return "Our boys' collection features durable, comfortable clothing that can keep up with their adventures.";
      case 'girls':
        return "Discover stylish and comfortable clothing for girls in our curated collection.";
      case 'infants':
        return "Soft, safe, and adorable clothing for the littlest ones in your life.";
      default:
        return getCategoryDescription(categorySlug);
    }
  }
  
  return getCategoryDescription(categorySlug);
}

/**
 * Get a map of color codes for display
 */
export const colorMap: Record<string, string> = {
  black: '#000000',
  white: '#FFFFFF',
  red: '#F44336',
  blue: '#2196F3',
  gray: '#9E9E9E',
  green: '#4CAF50',
  purple: '#9C27B0',
  yellow: '#FFEB3B',
  pink: '#E91E63',
  brown: '#795548',
  multicolor: 'linear-gradient(45deg, red, blue, green)'
};

/**
 * Utility function to format currency
 */
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2
  }).format(value);
}

/**
 * Get meta description for a product
 */
export function getProductMetaDescription(product: Product): string {
  return `Shop ${product.name} at Square Bidness Apparel. ${product.description.split('.')[0]}. Available in ${product.colors.length} colors and ${product.sizes.length} sizes.`;
}

/**
 * Get meta description for a category
 */
export function getCategoryMetaDescription(categorySlug: string, subcategorySlug?: string): string {
  if (subcategorySlug) {
    return `Shop our ${getSubcategoryTitle(categorySlug, subcategorySlug)} collection at Square Bidness Apparel. ${getSubcategoryDescription(categorySlug, subcategorySlug)}`;
  }
  
  return `Shop our ${getCategoryTitle(categorySlug)} at Square Bidness Apparel. ${getCategoryDescription(categorySlug)}`;
}

/**
 * Get formatted title for a category
 */
export function getCategoryTitle(categorySlug: string): string {
  switch (categorySlug) {
    case 'men':
      return "Men's Collection";
    case 'women':
      return "Women's Collection";
    case 'kids':
      return "Kids' Collection";
    case 'sale':
      return "Sale Collection";
    case 'new':
      return "New Arrivals";
    default:
      return categorySlug.charAt(0).toUpperCase() + categorySlug.slice(1);
  }
}

/**
 * Get formatted title for a subcategory
 */
export function getSubcategoryTitle(categorySlug: string, subcategorySlug: string): string {
  const subcategory = getSubcategoryBySlug(categorySlug, subcategorySlug);
  
  if (subcategory) {
    return `${subcategory.name.charAt(0) + subcategory.name.slice(1).toLowerCase()}`;
  }
  
  return subcategorySlug.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

/**
 * Get a product's breadcrumb trail
 */
export function getProductBreadcrumbs(product: Product): { label: string, href: string }[] {
  return [
    { label: 'Home', href: '/' },
    { label: getCategoryTitle(product.category), href: `/category/${product.category}` },
    { label: getSubcategoryTitle(product.category, product.subcategory), href: `/category/${product.category}/${product.subcategory}` },
    { label: product.name, href: `/product/${product.id}` }
  ];
}
