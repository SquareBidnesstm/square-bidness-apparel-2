import React from 'react';

interface LogoProps {
  className?: string;
}

export const SquareBidnessLogo: React.FC<LogoProps> = ({ className }) => {
  return (
    <img 
      src="/textlogo.png" 
      alt="Square Bidness Apparel" 
      className={className}
    />
  );
};
