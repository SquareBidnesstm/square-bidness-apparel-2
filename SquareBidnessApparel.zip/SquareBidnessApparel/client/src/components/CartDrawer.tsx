import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetFooter 
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useState } from 'react';
import { Link } from 'wouter';
import { ShoppingBag } from 'lucide-react';

interface CartDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CartDrawer({ open, onOpenChange }: CartDrawerProps) {
  // This is a simplified cart drawer that doesn't use the CartContext
  // It will be replaced with the fully functional cart when the context issue is fixed
  
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-md flex flex-col">
        <SheetHeader>
          <SheetTitle className="text-xl font-montserrat flex items-center">
            <ShoppingBag className="mr-2 h-5 w-5" />
            Your Shopping Cart
          </SheetTitle>
        </SheetHeader>
        
        <div className="flex-1 flex flex-col items-center justify-center text-center py-10">
          <ShoppingBag className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="font-medium text-lg mb-2">Your cart is empty</h3>
          <p className="text-muted-foreground mb-6">Looks like you haven't added any items to your cart yet.</p>
          <Button onClick={() => onOpenChange(false)} className="bg-primary hover:bg-neutral-800">
            Continue Shopping
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}