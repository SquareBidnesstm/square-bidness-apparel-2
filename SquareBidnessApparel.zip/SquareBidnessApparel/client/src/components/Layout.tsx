import React, { useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { CartDrawer } from './CartDrawer';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  // State for cart drawer
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onCartClick={() => setIsCartOpen(true)} />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      
      {/* Cart Drawer */}
      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
    </div>
  );
}
