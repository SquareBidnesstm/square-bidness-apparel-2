import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function NewsletterSignup() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      toast({
        title: "Error",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Subscribed!",
        description: "Thank you for subscribing to our newsletter.",
      });
      setEmail('');
      setIsSubmitting(false);
    }, 1000);
  };
  
  return (
    <section className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4 font-montserrat">JOIN THE SQUARE BIDNESS COMMUNITY</h2>
        <p className="mb-8 max-w-2xl mx-auto">
          Sign up for our newsletter to receive exclusive offers, early access to new collections, and style tips from our fashion experts.
        </p>
        
        <div className="max-w-md mx-auto">
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
            <Input
              type="email"
              placeholder="Your email address"
              className="flex-1 px-4 py-3 rounded-full focus:outline-none text-neutral-800"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isSubmitting}
            />
            <Button 
              type="submit"
              className="bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-full transition duration-300 shadow-md"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'SUBSCRIBING...' : 'SUBSCRIBE'}
            </Button>
          </form>
        </div>
        
        <div className="mt-12 flex justify-center space-x-6">
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition duration-300">
            <i className="fab fa-instagram text-2xl"></i>
          </a>
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition duration-300">
            <i className="fab fa-facebook text-2xl"></i>
          </a>
          <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition duration-300">
            <i className="fab fa-twitter text-2xl"></i>
          </a>
          <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="text-white hover:text-accent transition duration-300">
            <i className="fab fa-tiktok text-2xl"></i>
          </a>
        </div>
      </div>
    </section>
  );
}
