import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Product } from '@/lib/types';

interface CategoryCardProps {
  title: string;
  image: string;
  link: string;
  subcategory?: string;
}

export default function CategoryCard({ title, image, link }: CategoryCardProps) {
  return (
    <div className="relative overflow-hidden rounded-lg group cursor-pointer">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-80 object-cover transition duration-300 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-black bg-opacity-40 transition duration-300 group-hover:bg-opacity-50 flex items-center justify-center">
        <div className="text-center">
          <h3 className="text-white text-xl font-bold font-montserrat mb-2">{title}</h3>
          <Link href={link} className="inline-block bg-white text-primary px-4 py-2 rounded-full text-sm font-medium transition duration-300 hover:bg-accent hover:text-white">
            SHOP NOW
          </Link>
        </div>
      </div>
    </div>
  );
}
