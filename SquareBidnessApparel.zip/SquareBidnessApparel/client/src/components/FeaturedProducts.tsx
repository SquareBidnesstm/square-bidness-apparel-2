import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import ProductCard from './ProductCard';
import { Button } from '@/components/ui/button';
import { Product } from '@/lib/types';
import { Skeleton } from '@/components/ui/skeleton';

export default function FeaturedProducts() {
  const { data: featuredProducts, isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    staleTime: 60000, // 1 minute
  });
  
  // Filter for featured products only
  const filteredProducts = featuredProducts?.filter(product => product.featured).slice(0, 4);
  
  if (error) {
    return (
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center font-montserrat">FEATURED PRODUCTS</h2>
        <div className="text-center text-red-500">
          Failed to load products. Please try again later.
        </div>
      </section>
    );
  }
  
  return (
    <section className="py-16 container mx-auto px-4">
      <h2 className="text-3xl font-bold mb-8 text-center font-montserrat">FEATURED PRODUCTS</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {isLoading ? (
          // Loading skeletons
          Array(4).fill(0).map((_, index) => (
            <div key={index} className="rounded-lg shadow-md overflow-hidden">
              <Skeleton className="h-80 w-full" />
              <div className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-4" />
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-1/4" />
                  <Skeleton className="h-8 w-1/3 rounded-full" />
                </div>
              </div>
            </div>
          ))
        ) : filteredProducts && filteredProducts.length > 0 ? (
          // Render product cards
          filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))
        ) : (
          <div className="col-span-full text-center text-gray-500">
            No featured products available at the moment.
          </div>
        )}
      </div>
      
      <div className="mt-12 text-center">
        <Link href="/products">
          <Button className="bg-primary hover:bg-neutral-800 text-white font-bold py-3 px-8 rounded-full transition duration-300 shadow-lg">
            VIEW ALL PRODUCTS
          </Button>
        </Link>
      </div>
    </section>
  );
}
