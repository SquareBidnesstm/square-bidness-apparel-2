import { Link } from 'wouter';

interface StoreDisplayProps {
  displays: {
    image: string;
    title: string;
    description: string;
    buttonText: string;
    buttonLink: string;
  }[];
}

export default function StoreDisplay({ displays }: StoreDisplayProps) {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center font-montserrat">OUR COLLECTIONS</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {displays.map((display, index) => (
            <div key={index} className="relative overflow-hidden rounded-lg shadow-lg">
              <img 
                src={display.image} 
                alt={display.title} 
                className="w-full h-80 object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                <div className="text-center px-6">
                  <h3 className="text-white text-2xl font-bold font-montserrat mb-2">{display.title}</h3>
                  <p className="text-white mb-4">{display.description}</p>
                  <Link href={display.buttonLink} className="inline-block bg-white text-primary px-6 py-2 rounded-full font-medium transition duration-300 hover:bg-accent hover:text-white">
                    {display.buttonText}
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
