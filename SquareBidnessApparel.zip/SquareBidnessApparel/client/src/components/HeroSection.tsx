import { Link } from 'wouter';

export default function HeroSection() {
  return (
    <section className="relative h-[70vh] bg-primary overflow-hidden">
      {/* Overlay */}
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Clean Background */}
      <div className="absolute inset-0 bg-black"></div>
      
      {/* Content */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center px-4 md:px-8">
          <h1 className="text-4xl md:text-6xl font-bold text-white font-montserrat mb-4 leading-tight">
            VSOP COLLECTION
          </h1>
          <p className="text-xl md:text-2xl text-white font-light mb-2 max-w-2xl mx-auto">
            Fall 2025
          </p>
          <p className="text-lg md:text-xl text-white font-light mb-8 max-w-2xl mx-auto opacity-90">
            Coming Soon - The ultimate expression of luxury and style
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/category/men" className="bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-8 rounded-full transition duration-300 shadow-lg inline-block">
              EXPLORE COLLECTION
            </Link>
            <button className="bg-white hover:bg-opacity-90 text-primary font-bold py-3 px-8 rounded-full transition duration-300 shadow-lg border-2 border-white">
              NOTIFY ME
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
