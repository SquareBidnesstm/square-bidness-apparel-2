import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Product } from '@/lib/types';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  
  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      quantity: 1,
      color: selectedColor,
      size: product.sizes[0],
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
      duration: 3000,
    });
  };
  
  return (
    <div className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300">
      <div className="relative h-80 overflow-hidden">
        <Link href={`/product/${product.id}`}>
          <a>
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover transition-all duration-500 group-hover:scale-105"
            />
          </a>
        </Link>
        {product.new && (
          <div className="absolute top-3 right-3 bg-accent text-white text-xs px-2 py-1 rounded-full">NEW</div>
        )}
        {product.trending && (
          <div className="absolute top-3 right-3 bg-accent text-white text-xs px-2 py-1 rounded-full">TRENDING</div>
        )}
        {product.bestseller && (
          <div className="absolute top-3 right-3 bg-success text-white text-xs px-2 py-1 rounded-full">BESTSELLER</div>
        )}
        {product.hot && (
          <div className="absolute top-3 right-3 bg-accent text-white text-xs px-2 py-1 rounded-full">HOT</div>
        )}
      </div>
      
      <div className="p-4 bg-white">
        <div className="flex justify-between items-start">
          <div>
            <Link href={`/product/${product.id}`}>
              <a>
                <h3 className="font-montserrat font-semibold text-lg mb-1">{product.name}</h3>
              </a>
            </Link>
            <p className="text-neutral-800 text-sm">{product.category.charAt(0).toUpperCase() + product.category.slice(1)}'s Collection</p>
          </div>
          <div className="font-montserrat font-bold text-lg">${product.price.toFixed(2)}</div>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex space-x-2">
            {product.colors.slice(0, 3).map(color => (
              <button
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`w-4 h-4 rounded-full border ${selectedColor === color ? 'border-accent' : 'border-neutral-200'}`}
                style={{ 
                  backgroundColor: 
                    color === 'black' ? '#000' : 
                    color === 'white' ? '#fff' : 
                    color === 'red' ? '#f44336' : 
                    color === 'blue' ? '#2196f3' : 
                    color === 'gray' ? '#9e9e9e' : 
                    color === 'green' ? '#4caf50' : 
                    color === 'purple' ? '#9c27b0' : 
                    color === 'yellow' ? '#ffeb3b' : 
                    color === 'pink' ? '#e91e63' : 
                    color === 'brown' ? '#795548' : 
                    color === 'multicolor' ? 'linear-gradient(45deg, red, blue, green)' : '#ddd'
                }}
                aria-label={`Select ${color} color`}
              />
            ))}
          </div>
          
          <Button 
            onClick={handleAddToCart}
            className="bg-primary hover:bg-neutral-800 text-white px-4 py-2 rounded-full text-sm font-medium transition duration-300"
          >
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
}
