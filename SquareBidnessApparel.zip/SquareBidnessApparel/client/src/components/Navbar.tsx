import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { SquareBidnessLogo } from '@/lib/utils/logo';

// Temporarily missing icons - will fix later
const SearchIcon = () => <span>🔍</span>;
const UserIcon = () => <span>👤</span>;
const ShoppingBag = () => <span>🛍️</span>;
const MenuIcon = () => <span>☰</span>;

interface NavbarProps {
  onCartClick?: () => void;
}

export default function Navbar({ onCartClick }: NavbarProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Temporary cart state until provider issues are fixed
  const cartItemCount = 0;

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Handle search logic here
      console.log('Searching for:', searchQuery);
    }
  };

  return (
    <header className={`bg-primary text-white sticky top-0 z-50 ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="block">
              <SquareBidnessLogo className="h-12" />
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className={`text-white hover:text-accent font-montserrat font-medium ${location === '/' ? 'text-accent' : ''}`}>
              Home
            </Link>
            <div className="relative group">
              <Link href="/category/men" className={`text-white hover:text-accent font-montserrat font-medium ${location.includes('/category/men') ? 'text-accent' : ''}`}>
                Men
              </Link>
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md hidden group-hover:block">
                <div className="py-2 px-4">
                  <Link href="/category/men/t-shirts" className="block py-2 text-sm text-neutral-800 hover:text-accent">T-Shirts</Link>
                  <Link href="/category/men/hoodies" className="block py-2 text-sm text-neutral-800 hover:text-accent">Hoodies</Link>
                  <Link href="/category/men/jeans" className="block py-2 text-sm text-neutral-800 hover:text-accent">Jeans</Link>
                  <Link href="/category/men/accessories" className="block py-2 text-sm text-neutral-800 hover:text-accent">Accessories</Link>
                </div>
              </div>
            </div>
            <div className="relative group">
              <Link href="/category/women" className={`text-white hover:text-accent font-montserrat font-medium ${location.includes('/category/women') ? 'text-accent' : ''}`}>
                Women
              </Link>
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md hidden group-hover:block">
                <div className="py-2 px-4">
                  <Link href="/category/women/dresses" className="block py-2 text-sm text-neutral-800 hover:text-accent">Dresses</Link>
                  <Link href="/category/women/tops" className="block py-2 text-sm text-neutral-800 hover:text-accent">Tops</Link>
                  <Link href="/category/women/bottoms" className="block py-2 text-sm text-neutral-800 hover:text-accent">Bottoms</Link>
                  <Link href="/category/women/accessories" className="block py-2 text-sm text-neutral-800 hover:text-accent">Accessories</Link>
                </div>
              </div>
            </div>
            <div className="relative group">
              <Link href="/category/kids" className={`text-white hover:text-accent font-montserrat font-medium ${location.includes('/category/kids') ? 'text-accent' : ''}`}>
                Kids
              </Link>
              <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md hidden group-hover:block">
                <div className="py-2 px-4">
                  <Link href="/category/kids/boys" className="block py-2 text-sm text-neutral-800 hover:text-accent">Boys</Link>
                  <Link href="/category/kids/girls" className="block py-2 text-sm text-neutral-800 hover:text-accent">Girls</Link>
                  <Link href="/category/kids/infants" className="block py-2 text-sm text-neutral-800 hover:text-accent">Infants</Link>
                </div>
              </div>
            </div>
            <Link href="/category/sale" className={`text-white hover:text-accent font-montserrat font-medium ${location === '/category/sale' ? 'text-accent' : ''}`}>
              Sale
            </Link>
            <Link href="/about" className={`text-white hover:text-accent font-montserrat font-medium ${location === '/about' ? 'text-accent' : ''}`}>
              About
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            {/* Desktop Search */}
            <div className="relative hidden md:block">
              <form onSubmit={handleSearch}>
                <Input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 rounded-full text-sm bg-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-accent"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute left-3 top-2.5">
                  <SearchIcon />
                </div>
              </form>
            </div>
            
            {/* User Account */}
            <div className="relative">
              <Link href="/account" className="text-white hover:text-accent">
                <UserIcon />
              </Link>
            </div>
            
            {/* Cart */}
            <div className="relative">
              <button 
                onClick={onCartClick} 
                className="text-white hover:text-accent"
              >
                <ShoppingBag />
                {cartItemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-accent text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </button>
            </div>
            
            {/* Mobile Menu Button */}
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" className="md:hidden text-white p-0 hover:bg-transparent" aria-label="Menu">
                  <MenuIcon />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-primary text-white w-[300px] pt-12">
                <div className="flex flex-col space-y-4">
                  <Link href="/" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    Home
                  </Link>
                  <Link href="/category/men" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    Men
                  </Link>
                  <Link href="/category/women" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    Women
                  </Link>
                  <Link href="/category/kids" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    Kids
                  </Link>
                  <Link href="/category/sale" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    Sale
                  </Link>
                  <Link href="/about" className="text-white hover:text-accent font-montserrat font-medium" onClick={() => setIsMobileMenuOpen(false)}>
                    About
                  </Link>
                  
                  {/* Mobile Search */}
                  <form onSubmit={handleSearch} className="mt-4">
                    <div className="relative">
                      <Input
                        type="text"
                        placeholder="Search..."
                        className="w-full pl-10 pr-4 py-2 rounded-full text-sm bg-neutral-800 text-white focus:outline-none focus:ring-2 focus:ring-accent"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                      <div className="absolute left-3 top-2.5">
                        <i className="fas fa-search text-white"></i>
                      </div>
                    </div>
                  </form>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
