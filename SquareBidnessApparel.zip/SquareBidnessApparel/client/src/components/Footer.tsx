import { Link } from 'wouter';
import { SquareBidnessLogo } from '@/lib/utils/logo';

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <SquareBidnessLogo className="h-12 mb-6" />
            <p className="text-neutral-400 mb-6">
              Premium apparel for those who dare to express themselves. Quality craftsmanship meets urban style.
            </p>
            <div className="flex space-x-4">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent transition duration-300">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent transition duration-300">
                <i className="fab fa-facebook"></i>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent transition duration-300">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="text-neutral-400 hover:text-accent transition duration-300">
                <i className="fab fa-tiktok"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 font-montserrat">SHOP</h3>
            <ul className="space-y-3">
              <li><Link href="/category/men" className="text-neutral-400 hover:text-accent transition duration-300">Men's Collection</Link></li>
              <li><Link href="/category/women" className="text-neutral-400 hover:text-accent transition duration-300">Women's Collection</Link></li>
              <li><Link href="/category/kids" className="text-neutral-400 hover:text-accent transition duration-300">Kids' Collection</Link></li>
              <li><Link href="/category/new" className="text-neutral-400 hover:text-accent transition duration-300">New Arrivals</Link></li>
              <li><Link href="/category/sale" className="text-neutral-400 hover:text-accent transition duration-300">Sale</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 font-montserrat">CUSTOMER SERVICE</h3>
            <ul className="space-y-3">
              <li><Link href="/contact" className="text-neutral-400 hover:text-accent transition duration-300">Contact Us</Link></li>
              <li><Link href="/shipping" className="text-neutral-400 hover:text-accent transition duration-300">Shipping Policy</Link></li>
              <li><Link href="/returns" className="text-neutral-400 hover:text-accent transition duration-300">Returns & Exchanges</Link></li>
              <li><Link href="/size-guide" className="text-neutral-400 hover:text-accent transition duration-300">Size Guide</Link></li>
              <li><Link href="/faq" className="text-neutral-400 hover:text-accent transition duration-300">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-6 font-montserrat">ABOUT</h3>
            <ul className="space-y-3">
              <li><Link href="/about" className="text-neutral-400 hover:text-accent transition duration-300">Our Story</Link></li>
              <li><Link href="/blog" className="text-neutral-400 hover:text-accent transition duration-300">Blog</Link></li>
              <li><Link href="/sustainability" className="text-neutral-400 hover:text-accent transition duration-300">Sustainability</Link></li>
              <li><Link href="/stores" className="text-neutral-400 hover:text-accent transition duration-300">Store Locations</Link></li>
              <li><Link href="/careers" className="text-neutral-400 hover:text-accent transition duration-300">Careers</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-400 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Square Bidness Apparel. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link href="/privacy" className="text-neutral-400 text-sm hover:text-accent transition duration-300">Privacy Policy</Link>
            <Link href="/terms" className="text-neutral-400 text-sm hover:text-accent transition duration-300">Terms of Service</Link>
            <Link href="/accessibility" className="text-neutral-400 text-sm hover:text-accent transition duration-300">Accessibility</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
