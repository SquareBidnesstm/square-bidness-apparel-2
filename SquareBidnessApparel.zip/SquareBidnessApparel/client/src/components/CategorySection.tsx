import { useQuery } from '@tanstack/react-query';
import CategoryCard from './CategoryCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Product } from '@/lib/types';

interface CategorySectionProps {
  title: string;
  description: string;
  category: string;
  subcategories: {
    title: string;
    slug: string;
    image: string;
  }[];
  bgColor: string;
}

export default function CategorySection({
  title,
  description,
  category,
  subcategories,
  bgColor,
}: CategorySectionProps) {
  const { isLoading } = useQuery<Product[]>({
    queryKey: [`/api/products/category/${category}`],
    staleTime: 60000, // 1 minute
  });
  
  return (
    <section id={category} className={`py-16 ${bgColor}`}>
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-4 text-center font-montserrat">{title}</h2>
        <p className="text-center text-neutral-800 mb-12 max-w-2xl mx-auto">{description}</p>
        
        <div className={`grid grid-cols-1 md:grid-cols-2 ${subcategories.length > 3 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-6`}>
          {isLoading ? (
            // Loading skeletons
            Array(subcategories.length).fill(0).map((_, index) => (
              <div key={index} className="rounded-lg overflow-hidden">
                <Skeleton className="h-80 w-full" />
              </div>
            ))
          ) : (
            // Render category cards
            subcategories.map((subcategory) => (
              <CategoryCard
                key={subcategory.slug}
                title={subcategory.title}
                image={subcategory.image}
                link={`/category/${category}/${subcategory.slug}`}
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
}
