import { Link, useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/data';

export default function CartPage() {
  const { cartItems, updateCartItemQuantity, removeFromCart } = useCart();
  const [, setLocation] = useLocation();
  
  // Calculate cart total
  const cartTotal = cartItems.reduce((total, item) => 
    total + (item.product.price * item.quantity), 0
  );
  
  // Handle quantity change
  const handleQuantityChange = (id: number, newQuantity: number) => {
    if (newQuantity >= 1 && newQuantity <= 99) {
      updateCartItemQuantity(id, newQuantity);
    }
  };
  
  // Handle checkout button
  const handleCheckout = () => {
    setLocation('/checkout');
  };

  return (
    <>
      <Helmet>
        <title>Shopping Cart | Square Bidness Apparel</title>
        <meta name="description" content="Review your shopping cart at Square Bidness Apparel. Adjust quantities or proceed to checkout." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Your Shopping Cart</h1>
        
        {cartItems.length === 0 ? (
          <div className="bg-neutral-50 p-8 rounded-lg text-center">
            <h2 className="text-2xl font-semibold mb-4">Your cart is empty</h2>
            <p className="mb-6">Looks like you haven't added any items to your cart yet.</p>
            <Link href="/">
              <Button className="bg-primary text-white font-bold py-3 px-8 rounded-full">
                Start Shopping
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <div key={item.id} className="bg-white p-4 rounded-lg shadow-sm border border-neutral-200 flex flex-col md:flex-row">
                  {/* Product Image */}
                  <div className="w-full md:w-32 h-32 mb-4 md:mb-0 flex-shrink-0">
                    <img 
                      src={item.product.image} 
                      alt={item.product.name} 
                      className="w-full h-full object-cover rounded-md"
                    />
                  </div>
                  
                  {/* Product Details */}
                  <div className="flex-grow md:ml-4 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between">
                        <h3 className="font-bold text-lg">{item.product.name}</h3>
                        <span className="font-bold">
                          {formatCurrency(item.product.price * item.quantity)}
                        </span>
                      </div>
                      
                      <div className="text-neutral-600 mb-4">
                        <p>Color: {item.color}</p>
                        <p>Size: {item.size}</p>
                        <p>Price: {formatCurrency(item.product.price)}</p>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      {/* Quantity Selector */}
                      <div className="flex items-center">
                        <button 
                          onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          className="w-8 h-8 border border-neutral-300 flex items-center justify-center rounded-l-md"
                          disabled={item.quantity <= 1}
                        >
                          -
                        </button>
                        <span className="w-12 h-8 border-t border-b border-neutral-300 flex items-center justify-center">
                          {item.quantity}
                        </span>
                        <button 
                          onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          className="w-8 h-8 border border-neutral-300 flex items-center justify-center rounded-r-md"
                        >
                          +
                        </button>
                      </div>
                      
                      {/* Remove Button */}
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white p-6 rounded-lg shadow-sm border border-neutral-200 sticky top-24">
                <h2 className="text-xl font-bold mb-6">Order Summary</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatCurrency(cartTotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>FREE</span>
                  </div>
                  <div className="border-t border-neutral-200 pt-4 flex justify-between font-bold">
                    <span>Total</span>
                    <span>{formatCurrency(cartTotal)}</span>
                  </div>
                </div>
                
                <Button 
                  onClick={handleCheckout}
                  className="w-full bg-primary hover:bg-primary-dark text-white font-bold py-3 rounded-full"
                >
                  Proceed to Checkout
                </Button>
                
                <div className="mt-4 text-center">
                  <Link href="/" className="text-primary hover:text-primary-dark text-sm">
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}