import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Product } from '@/lib/types';
import ProductCard from '@/components/ProductCard';
import { Skeleton } from '@/components/ui/skeleton';
import { useState } from 'react';
import { Helmet } from 'react-helmet';

export default function CategoryPage() {
  // Get category and subcategory from URL
  const [, params] = useRoute('/category/:category/:subcategory?');
  const { category, subcategory } = params || {};
  
  // State for filters
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState('newest');
  
  // Fetch products
  const { data: products, isLoading, error } = useQuery<Product[]>({
    queryKey: [subcategory 
      ? `/api/products/subcategory/${subcategory}`
      : `/api/products/category/${category}`
    ],
    staleTime: 60000, // 1 minute
  });
  
  // Apply filters and sorting
  const filteredProducts = products?.filter(product => {
    // Price filter
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false;
    }
    
    // Color filter
    if (selectedColors.length > 0 && !product.colors.some(color => selectedColors.includes(color))) {
      return false;
    }
    
    // Size filter
    if (selectedSizes.length > 0 && !product.sizes.some(size => selectedSizes.includes(size))) {
      return false;
    }
    
    return true;
  }).sort((a, b) => {
    // Sorting
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      case 'newest':
      default:
        return 0; // Assume default sort is by newest
    }
  });
  
  // Get category title
  const getCategoryTitle = () => {
    if (subcategory) {
      return subcategory.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    }
    return category?.charAt(0).toUpperCase() + category?.slice(1);
  };
  
  // Handle filter changes
  const handleColorFilter = (color: string) => {
    if (selectedColors.includes(color)) {
      setSelectedColors(selectedColors.filter(c => c !== color));
    } else {
      setSelectedColors([...selectedColors, color]);
    }
  };
  
  const handleSizeFilter = (size: string) => {
    if (selectedSizes.includes(size)) {
      setSelectedSizes(selectedSizes.filter(s => s !== size));
    } else {
      setSelectedSizes([...selectedSizes, size]);
    }
  };
  
  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Category Not Found</h1>
        <p className="text-neutral-600 mb-6">Sorry, we couldn't find the category you're looking for.</p>
      </div>
    );
  }
  
  // Get all available colors and sizes
  const allColors = Array.from(new Set(products?.flatMap(p => p.colors) || []));
  const allSizes = Array.from(new Set(products?.flatMap(p => p.sizes) || []));
  
  return (
    <>
      <Helmet>
        <title>{getCategoryTitle()} Collection | Square Bidness Apparel</title>
        <meta name="description" content={`Shop our ${getCategoryTitle()} collection at Square Bidness. Find premium quality clothing and accessories.`} />
      </Helmet>
      
      <div className="bg-neutral-100 py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2 font-montserrat">{getCategoryTitle()} Collection</h1>
          <p className="text-neutral-600 mb-6">
            {subcategory 
              ? `Explore our premium ${getCategoryTitle()} collection designed for style and comfort.`
              : `Discover our curated ${getCategoryTitle()} collection, featuring the latest styles and trends.`
            }
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Filters - Desktop */}
            <div className="hidden md:block">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <h2 className="font-montserrat font-semibold text-lg mb-4">Filters</h2>
                
                {/* Price Range Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Price</h3>
                  <div className="flex items-center justify-between mb-2">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="200"
                    step="10"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full"
                  />
                </div>
                
                {/* Color Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Color</h3>
                  <div className="flex flex-wrap gap-2">
                    {allColors.map(color => (
                      <button
                        key={color}
                        className={`w-6 h-6 rounded-full border ${
                          selectedColors.includes(color) ? 'border-accent' : 'border-neutral-200'
                        }`}
                        style={{ 
                          backgroundColor: 
                            color === 'black' ? '#000' : 
                            color === 'white' ? '#fff' : 
                            color === 'red' ? '#f44336' : 
                            color === 'blue' ? '#2196f3' : 
                            color === 'gray' ? '#9e9e9e' : 
                            color === 'green' ? '#4caf50' : 
                            color === 'purple' ? '#9c27b0' : 
                            color === 'yellow' ? '#ffeb3b' : 
                            color === 'pink' ? '#e91e63' : 
                            color === 'brown' ? '#795548' : 
                            color === 'multicolor' ? 'linear-gradient(45deg, red, blue, green)' : '#ddd'
                        }}
                        onClick={() => handleColorFilter(color)}
                        aria-label={`Filter by ${color} color`}
                      />
                    ))}
                  </div>
                </div>
                
                {/* Size Filter */}
                <div className="mb-6">
                  <h3 className="font-medium mb-2">Size</h3>
                  <div className="flex flex-wrap gap-2">
                    {allSizes.map(size => (
                      <button
                        key={size}
                        className={`px-2 py-1 text-sm border rounded-md ${
                          selectedSizes.includes(size)
                            ? 'border-accent bg-accent text-white'
                            : 'border-neutral-300'
                        }`}
                        onClick={() => handleSizeFilter(size)}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Products Grid */}
            <div className="md:col-span-3">
              {/* Sort and Count */}
              <div className="flex flex-wrap justify-between items-center mb-6">
                <p className="text-sm text-neutral-600">
                  {isLoading ? 'Loading products...' : `${filteredProducts?.length || 0} products found`}
                </p>
                
                <div className="flex items-center">
                  <label htmlFor="sort" className="text-sm mr-2">Sort by:</label>
                  <select
                    id="sort"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="text-sm border rounded-md p-1"
                  >
                    <option value="newest">Newest</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                    <option value="rating">Highest Rated</option>
                  </select>
                </div>
              </div>
              
              {/* Products */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  // Loading skeletons
                  Array(6).fill(0).map((_, index) => (
                    <div key={index} className="rounded-lg shadow-md overflow-hidden">
                      <Skeleton className="h-80 w-full" />
                      <div className="p-4">
                        <Skeleton className="h-6 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2 mb-4" />
                        <div className="flex justify-between">
                          <Skeleton className="h-4 w-1/4" />
                          <Skeleton className="h-8 w-1/3 rounded-full" />
                        </div>
                      </div>
                    </div>
                  ))
                ) : filteredProducts && filteredProducts.length > 0 ? (
                  // Render product cards
                  filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  <div className="col-span-full text-center py-16">
                    <div className="max-w-md mx-auto">
                      <div className="mb-6">
                        <svg className="mx-auto h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                      </div>
                      <h3 className="text-2xl font-bold mb-3 text-gray-900">Coming Soon</h3>
                      <p className="text-lg text-gray-600 mb-4">
                        We're working hard to bring you amazing {getCategoryTitle().toLowerCase()} products.
                      </p>
                      <p className="text-sm text-gray-500 mb-6">
                        Check back soon for new arrivals in this collection.
                      </p>
                      <div className="space-y-3">
                        <Link href="/">
                          <a className="inline-block bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-6 rounded-lg transition-colors">
                            Shop Other Collections
                          </a>
                        </Link>
                        <p className="text-xs text-gray-400">
                          Want to be notified? Follow us on social media for updates.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
