import { useState } from 'react';
import { useRoute } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Product } from '@/lib/types';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Helmet } from 'react-helmet';

export default function ProductDetail() {
  // Get product ID from URL
  const [, params] = useRoute('/product/:id');
  const productId = params?.id ? parseInt(params.id) : 0;
  
  // State for selected options
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  
  // Get cart functionality
  const { addToCart } = useCart();
  const { toast } = useToast();
  
  // Fetch product data
  const { data: product, isLoading, error } = useQuery<Product>({
    queryKey: [`/api/products/${productId}`],
    staleTime: 60000, // 1 minute
  });
  
  // Set initial selected options once product data is loaded
  useState(() => {
    if (product && !selectedColor) {
      setSelectedColor(product.colors[0]);
    }
    if (product && !selectedSize) {
      setSelectedSize(product.sizes[0]);
    }
  });
  
  // Handle quantity change
  const handleQuantityChange = (amount: number) => {
    const newQuantity = quantity + amount;
    if (newQuantity >= 1 && newQuantity <= 99) {
      setQuantity(newQuantity);
    }
  };
  
  // Handle add to cart
  const handleAddToCart = () => {
    if (!product || !selectedColor || !selectedSize) return;
    
    addToCart({
      productId: product.id,
      quantity,
      color: selectedColor,
      size: selectedSize,
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
      duration: 3000,
    });
  };
  
  // Handle buy now
  const handleBuyNow = () => {
    if (!product || !selectedColor || !selectedSize) return;
    
    addToCart({
      productId: product.id,
      quantity,
      color: selectedColor,
      size: selectedSize,
    });
    
    // Redirect to checkout page
    window.location.href = "/checkout";
  };
  
  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="text-neutral-600 mb-6">Sorry, we couldn't find the product you're looking for.</p>
        <Button onClick={() => window.history.back()}>Go Back</Button>
      </div>
    );
  }
  
  if (isLoading || !product) {
    return (
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-4">
              <Skeleton className="h-96 w-full rounded-lg" />
              <div className="grid grid-cols-4 gap-4">
                {[...Array(4)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full rounded-lg" />
                ))}
              </div>
            </div>
            
            <div>
              <Skeleton className="h-10 w-3/4 mb-4" />
              <Skeleton className="h-6 w-1/2 mb-4" />
              <Skeleton className="h-8 w-1/4 mb-6" />
              <Skeleton className="h-24 w-full mb-6" />
              
              <Skeleton className="h-6 w-1/3 mb-2" />
              <div className="flex space-x-2 mb-6">
                {[...Array(4)].map((_, i) => (
                  <Skeleton key={i} className="h-8 w-8 rounded-full" />
                ))}
              </div>
              
              <Skeleton className="h-6 w-1/3 mb-2" />
              <div className="flex flex-wrap gap-2 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-10 w-12 rounded-md" />
                ))}
              </div>
              
              <Skeleton className="h-6 w-1/3 mb-2" />
              <Skeleton className="h-10 w-32 mb-8" />
              
              <div className="flex gap-4">
                <Skeleton className="h-12 w-full rounded-full" />
                <Skeleton className="h-12 w-full rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>{product.name} | Square Bidness Apparel</title>
        <meta name="description" content={product.description} />
      </Helmet>
      
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-4">
              {/* Main product image */}
              <div className="bg-white rounded-lg overflow-hidden shadow-md">
                <img
                  src={product.image}
                  alt={`${product.name} - Main`}
                  className="w-full h-auto"
                />
              </div>
              
              {/* Thumbnail images */}
              <div className="grid grid-cols-4 gap-4">
                {product.images.slice(0, 4).map((image, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-lg overflow-hidden shadow-sm cursor-pointer hover:shadow-md transition duration-300"
                  >
                    <img
                      src={image}
                      alt={`${product.name} - Thumbnail ${index + 1}`}
                      className="w-full h-auto"
                    />
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h1 className="text-3xl font-bold font-montserrat mb-2">{product.name}</h1>
              <div className="flex items-center mb-4">
                <div className="flex text-yellow-500">
                  {[...Array(Math.floor(product.rating))].map((_, i) => (
                    <i key={i} className="fas fa-star"></i>
                  ))}
                  {product.rating % 1 !== 0 && (
                    <i className="fas fa-star-half-alt"></i>
                  )}
                </div>
                <span className="ml-2 text-sm text-neutral-800">
                  {product.rating} ({product.reviewCount} reviews)
                </span>
              </div>
              
              <div className="text-2xl font-bold font-montserrat mb-6">${product.price.toFixed(2)}</div>
              
              <p className="text-neutral-800 mb-6">
                {product.description}
              </p>
              
              {/* Color selection */}
              <div className="mb-6">
                <h4 className="font-semibold mb-2">Color</h4>
                <div className="flex space-x-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      className={`w-8 h-8 rounded-full focus:outline-none ${
                        selectedColor === color ? 'border-2 border-accent' : 'border-2 border-white'
                      }`}
                      style={{ 
                        backgroundColor: 
                          color === 'black' ? '#000' : 
                          color === 'white' ? '#fff' : 
                          color === 'red' ? '#f44336' : 
                          color === 'blue' ? '#2196f3' : 
                          color === 'gray' ? '#9e9e9e' : 
                          color === 'green' ? '#4caf50' : 
                          color === 'purple' ? '#9c27b0' : 
                          color === 'yellow' ? '#ffeb3b' : 
                          color === 'pink' ? '#e91e63' : 
                          color === 'brown' ? '#795548' : 
                          color === 'multicolor' ? 'linear-gradient(45deg, red, blue, green)' : '#ddd'
                      }}
                      onClick={() => setSelectedColor(color)}
                      aria-label={`Select ${color} color`}
                    ></button>
                  ))}
                </div>
              </div>
              
              {/* Size selection */}
              <div className="mb-6">
                <h4 className="font-semibold mb-2">Size</h4>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      className={`px-4 py-2 border rounded-md hover:border-accent focus:outline-none focus:border-accent ${
                        selectedSize === size
                          ? 'border-accent bg-accent text-white'
                          : 'border-neutral-300'
                      }`}
                      onClick={() => setSelectedSize(size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Quantity selection */}
              <div className="mb-8">
                <h4 className="font-semibold mb-2">Quantity</h4>
                <div className="flex items-center border border-neutral-300 rounded-md w-32">
                  <button
                    className="px-3 py-1 text-neutral-800 focus:outline-none"
                    onClick={() => handleQuantityChange(-1)}
                    disabled={quantity <= 1}
                  >
                    -
                  </button>
                  <input
                    type="text"
                    value={quantity}
                    className="w-full text-center focus:outline-none"
                    readOnly
                  />
                  <button
                    className="px-3 py-1 text-neutral-800 focus:outline-none"
                    onClick={() => handleQuantityChange(1)}
                    disabled={quantity >= 99}
                  >
                    +
                  </button>
                </div>
              </div>
              
              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  onClick={handleAddToCart}
                  className="flex-1 bg-accent hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-full transition duration-300 shadow-md"
                >
                  ADD TO CART
                </Button>
                <Button
                  onClick={handleBuyNow}
                  className="flex-1 bg-primary hover:bg-neutral-800 text-white font-bold py-3 px-6 rounded-full transition duration-300 shadow-md"
                >
                  BUY NOW
                </Button>
              </div>
              
              {/* Product details */}
              <div className="mt-8">
                <Separator className="my-6" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">Product Details</h4>
                    <ul className="text-sm space-y-1 text-neutral-700">
                      <li>Category: {product.category.charAt(0).toUpperCase() + product.category.slice(1)}'s</li>
                      <li>Subcategory: {product.subcategory.charAt(0).toUpperCase() + product.subcategory.slice(1)}</li>
                      <li>Available Colors: {product.colors.length}</li>
                      <li>Available Sizes: {product.sizes.length}</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Shipping & Returns</h4>
                    <ul className="text-sm space-y-1 text-neutral-700">
                      <li>Free shipping on orders over $50</li>
                      <li>30-day return policy</li>
                      <li>Free returns</li>
                      <li>Fast delivery (2-5 business days)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
