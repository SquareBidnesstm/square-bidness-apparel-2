import { useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';

export default function OrderConfirmation() {
  const [, setLocation] = useLocation();
  
  // Simulate checking for order details
  useEffect(() => {
    const timer = setTimeout(() => {
      // If no order details found after 3 seconds, redirect to home
      // This would be replaced with actual order validation in a real app
      if (!window.location.search.includes('payment_intent')) {
        setLocation('/');
      }
    }, 3000);
    
    return () => clearTimeout(timer);
  }, [setLocation]);
  
  return (
    <>
      <Helmet>
        <title>Order Confirmation | Square Bidness Apparel</title>
        <meta name="description" content="Thank you for your order at Square Bidness Apparel." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-12 max-w-3xl text-center">
        <div className="bg-white rounded-lg shadow-sm border border-neutral-200 p-8 mb-8">
          <div className="flex justify-center mb-6">
            <CheckCircle className="h-20 w-20 text-green-500" />
          </div>
          
          <h1 className="text-3xl font-bold mb-4">Order Confirmed!</h1>
          <p className="text-lg mb-8">
            Thank you for your purchase. We've received your order and will begin processing it right away.
          </p>
          
          <div className="mb-8 p-6 bg-neutral-50 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">What's Next?</h2>
            <p className="mb-4">
              You will receive an email confirmation with your order details and tracking information once your items have been shipped.
            </p>
            <p>
              If you have any questions about your order, please contact our customer service team.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-md w-full">
                Continue Shopping
              </Button>
            </Link>
            
            <Link href="/account/orders">
              <Button variant="outline" className="py-3 px-8 rounded-md w-full">
                View My Orders
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}