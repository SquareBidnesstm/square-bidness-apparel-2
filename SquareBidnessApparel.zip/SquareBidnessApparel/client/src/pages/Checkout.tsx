import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useEffect, useState } from 'react';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useCart } from '@/context/CartContext';
import { useLocation } from 'wouter';
import { Helmet } from 'react-helmet';
import { formatCurrency } from '@/lib/data';

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ amount }: { amount: number }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();
  const { clearCart } = useCart();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/order-confirmation',
        },
        redirect: 'if_required',
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
        setIsProcessing(false);
      } else {
        toast({
          title: "Payment Successful",
          description: "Thank you for your purchase!",
        });
        clearCart();
        setLocation('/order-confirmation');
      }
    } catch (err: any) {
      console.error('Payment error:', err);
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred during payment processing.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <button 
        disabled={!stripe || isProcessing}
        className="w-full py-3 px-4 bg-primary hover:bg-primary-dark text-white font-bold rounded-md disabled:opacity-70"
      >
        {isProcessing ? 'Processing...' : `Pay ${formatCurrency(amount)}`}
      </button>
    </form>
  );
};

export default function Checkout() {
  const [clientSecret, setClientSecret] = useState("");
  const { cartItems } = useCart();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Calculate cart total
  const cartTotal = cartItems.reduce((total, item) => 
    total + (item.product.price * item.quantity), 0
  );

  useEffect(() => {
    // Redirect if cart is empty
    if (cartItems.length === 0) {
      toast({
        title: "Empty Cart",
        description: "Your cart is empty. Please add items before checkout.",
      });
      setLocation('/');
      return;
    }

    // Create PaymentIntent as soon as the page loads
    apiRequest("POST", "/api/create-payment-intent", { amount: cartTotal })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch(err => {
        console.error("Error creating payment intent:", err);
        toast({
          title: "Payment Setup Failed",
          description: "We couldn't set up the payment process. Please try again.",
          variant: "destructive",
        });
      });
  }, [cartItems, cartTotal, setLocation, toast]);

  return (
    <>
      <Helmet>
        <title>Checkout | Square Bidness Apparel</title>
        <meta name="description" content="Complete your purchase securely at Square Bidness Apparel." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>
        
        <div className="bg-white rounded-lg shadow-sm border border-neutral-200 p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
          
          <div className="divide-y">
            {cartItems.map((item) => (
              <div key={item.id} className="py-4 flex items-center">
                <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0 mr-4">
                  <img 
                    src={item.product.image} 
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.product.name}</p>
                  <p className="text-sm text-neutral-600">
                    Color: {item.color} | Size: {item.size} | Qty: {item.quantity}
                  </p>
                </div>
                <div className="font-medium">
                  {formatCurrency(item.product.price * item.quantity)}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-4 pt-4 border-t border-neutral-200">
            <div className="flex justify-between font-medium text-lg">
              <span>Total</span>
              <span>{formatCurrency(cartTotal)}</span>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-neutral-200 p-6">
          <h2 className="text-xl font-semibold mb-4">Payment Information</h2>
          
          {!clientSecret ? (
            <div className="h-40 flex items-center justify-center">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
            </div>
          ) : (
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <CheckoutForm amount={cartTotal} />
            </Elements>
          )}
        </div>
      </div>
    </>
  );
}