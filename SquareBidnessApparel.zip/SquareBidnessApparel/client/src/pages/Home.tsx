import HeroSection from '@/components/HeroSection';
import FeaturedProducts from '@/components/FeaturedProducts';
import CategorySection from '@/components/CategorySection';
import StoreDisplay from '@/components/StoreDisplay';
import NewsletterSignup from '@/components/NewsletterSignup';
import { Helmet } from 'react-helmet';

export default function Home() {
  // Men's subcategories
  const mensSubcategories = [
    {
      title: 'T-SHIRTS',
      slug: 't-shirts',
      image: 'https://images.unsplash.com/photo-1516826957135-700dedea698c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'HOODIES',
      slug: 'hoodies',
      image: 'https://images.unsplash.com/photo-1613852348851-df1739db8201?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'JEANS',
      slug: 'jeans',
      image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'ACCESSORIES',
      slug: 'accessories',
      image: 'https://images.unsplash.com/photo-1624623278313-a930126a11c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    }
  ];
  
  // Women's subcategories
  const womensSubcategories = [
    {
      title: 'DRESSES',
      slug: 'dresses',
      image: 'https://images.unsplash.com/photo-1581044777550-4cfa60707c03?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'TOPS',
      slug: 'tops',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'BOTTOMS',
      slug: 'bottoms',
      image: 'https://images.unsplash.com/photo-1551489186-cf8726f514f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'ACCESSORIES',
      slug: 'accessories',
      image: 'https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    }
  ];
  
  // Kids' subcategories
  const kidsSubcategories = [
    {
      title: 'BOYS',
      slug: 'boys',
      image: 'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'GIRLS',
      slug: 'girls',
      image: 'https://images.unsplash.com/photo-1476234251651-f353703a034d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    },
    {
      title: 'INFANTS',
      slug: 'infants',
      image: 'https://images.unsplash.com/photo-1596870230751-ebdfce98ec42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000'
    }
  ];
  
  // Store displays
  const storeDisplays = [
    {
      image: 'https://images.unsplash.com/photo-1567401893414-76b7b1e5a7a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=800',
      title: 'PREMIUM QUALITY',
      description: 'Crafted with the finest materials for style and durability',
      buttonText: 'DISCOVER',
      buttonLink: '/quality'
    },
    {
      image: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=800',
      title: 'UNIQUE DESIGNS',
      description: 'Express your individuality with our exclusive styles',
      buttonText: 'EXPLORE',
      buttonLink: '/designs'
    }
  ];
  
  return (
    <>
      <Helmet>
        <title>Square Bidness Apparel | Premium Clothing for Men, Women & Kids</title>
        <meta name="description" content="Discover premium apparel at Square Bidness. Shop our collection of stylish clothing for men, women, and kids. Express yourself with unique designs and quality materials." />
      </Helmet>
      
      <HeroSection />
      
      <FeaturedProducts />
      
      <CategorySection
        title="MEN'S COLLECTION"
        description="Elevate your style with our premium men's apparel. From casual streetwear to sophisticated essentials."
        category="men"
        subcategories={mensSubcategories}
        bgColor="bg-neutral-200"
      />
      
      <CategorySection
        title="WOMEN'S COLLECTION"
        description="Discover our curated women's collection, designed for comfort, style, and self-expression."
        category="women"
        subcategories={womensSubcategories}
        bgColor="bg-white"
      />
      
      <CategorySection
        title="KIDS' COLLECTION"
        description="Stylish, comfortable, and durable apparel for the little ones. Because they deserve to look good too."
        category="kids"
        subcategories={kidsSubcategories}
        bgColor="bg-neutral-100"
      />
      
      <StoreDisplay displays={storeDisplays} />
      
      <NewsletterSignup />
    </>
  );
}
