import React, { createContext, useState, useContext, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { CartItem, Product } from '@/lib/types';

interface CartContextType {
  cartItems: CartItemWithProduct[];
  addToCart: (item: AddCartItemPayload) => void;
  updateCartItemQuantity: (id: number, quantity: number) => void;
  removeFromCart: (id: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
}

interface CartItemWithProduct extends CartItem {
  product: Product;
}

interface AddCartItemPayload {
  productId: number;
  quantity: number;
  color: string;
  size: string;
}

interface CartResponse {
  cart: {
    id: number;
    sessionId: string;
    createdAt: string;
  };
  items: CartItemWithProduct[];
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const queryClient = useQueryClient();
  
  // Fetch cart data
  const { data: cartData, isLoading } = useQuery<CartResponse>({
    queryKey: ['/api/cart'],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
  
  // Add item to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async (itemData: AddCartItemPayload) => {
      const response = await apiRequest('POST', '/api/cart/items', itemData);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/cart'], data);
    },
  });
  
  // Update cart item quantity mutation
  const updateQuantityMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      const response = await apiRequest('PATCH', `/api/cart/items/${id}`, { quantity });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/cart'], data);
    },
  });
  
  // Remove item from cart mutation
  const removeItemMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/cart/items/${id}`);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/cart'], data);
    },
  });
  
  // Clear cart mutation
  const clearCartMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('DELETE', '/api/cart');
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/cart'], data);
    },
  });
  
  // Cart actions
  const addToCart = (item: AddCartItemPayload) => {
    addToCartMutation.mutate(item);
    setIsCartOpen(true); // Open cart when adding item
  };
  
  const updateCartItemQuantity = (id: number, quantity: number) => {
    updateQuantityMutation.mutate({ id, quantity });
  };
  
  const removeFromCart = (id: number) => {
    removeItemMutation.mutate(id);
  };
  
  const clearCart = () => {
    clearCartMutation.mutate();
  };
  
  const openCart = () => {
    setIsCartOpen(true);
  };
  
  const closeCart = () => {
    setIsCartOpen(false);
  };
  
  return (
    <CartContext.Provider value={{
      cartItems: cartData?.items || [],
      addToCart,
      updateCartItemQuantity,
      removeFromCart,
      clearCart,
      isCartOpen,
      openCart,
      closeCart,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
