# Square Bidness Apparel - Vercel Deployment Guide

## Prerequisites
1. Vercel account (free at vercel.com)
2. GitHub repository with your code
3. PostgreSQL database (Neon, Supabase, or similar)
4. Stripe account for payments

## Step 1: Database Setup
1. Create a PostgreSQL database on Neon (neon.tech) or Supabase
2. Copy the connection string for environment variables

## Step 2: Vercel Deployment
1. Connect your GitHub repository to Vercel
2. Import your project in Vercel dashboard
3. Configure environment variables in Vercel:
   - `DATABASE_URL` - Your PostgreSQL connection string
   - `STRIPE_SECRET_KEY` - Your Stripe secret key
   - `VITE_STRIPE_PUBLIC_KEY` - Your Stripe public key
   - `SESSION_SECRET` - Random string for session security
   - `NODE_ENV` - Set to "production"

## Step 3: Custom Domain Setup
1. In Vercel dashboard, go to your project settings
2. Navigate to "Domains" section
3. Add your custom domain: squarebidness.com
4. Update your domain's DNS settings:
   - Add CNAME record: `www` pointing to `cname.vercel-dns.com`
   - Add A record: `@` pointing to `76.76.19.61`
5. Vercel will automatically handle SSL certificates

## Step 4: Database Migration
After deployment, run database migration:
```bash
npm run db:push
```

## Step 5: Testing
1. Test your deployed site at squarebidness.com
2. Verify all pages load correctly
3. Test user registration and login
4. Test product browsing and cart functionality

## Important Notes
- The app is configured for production deployment
- All environment variables must be set in Vercel
- Database tables will be created automatically on first run
- SSL certificates are handled automatically by Vercel

Your Square Bidness Apparel store will be live at squarebidness.com once deployed!