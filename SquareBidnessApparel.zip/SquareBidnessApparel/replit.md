# Square Bidness Apparel E-commerce Site

## Overview

This repository contains a full-stack e-commerce web application for "Square Bidness Apparel", a clothing retailer selling products for men, women, and kids. The application is built with React on the frontend and Express.js on the backend, using Drizzle ORM for database operations. It follows a modern architecture with server-side rendering capabilities and a RESTful API design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern client-server architecture with clear separation of concerns:

1. **Frontend**: React-based SPA (Single Page Application) with client-side routing using Wouter
2. **Backend**: Express.js server providing RESTful API endpoints
3. **Database**: Designed to use PostgreSQL with Drizzle ORM for type-safe database operations
4. **State Management**: Mix of React Context API for global state and React Query for server state
5. **Styling**: Tailwind CSS with the shadcn/ui component library (based on Radix UI)

The application is structured into three main directories:
- `client/`: Contains all frontend React code
- `server/`: Contains the Express.js backend
- `shared/`: Contains shared types and schemas used by both frontend and backend

## Key Components

### Frontend

1. **Routing**: Uses Wouter for lightweight client-side routing with routes for:
   - Home page
   - Product detail pages
   - Category pages with optional subcategory filtering

2. **State Management**:
   - React Query for data fetching, caching, and server state management
   - Context API for global application state (cart, theme)

3. **UI Components**:
   - Component library built with shadcn/ui and Radix UI primitives
   - Custom components for product listings, cart, product details, etc.
   - Responsive design with mobile-first approach

4. **Pages**:
   - Home: Features hero section, featured products, category browsing
   - Product Detail: Shows product information, allows adding to cart
   - Category: Displays products filtered by category/subcategory

### Backend

1. **API Routes**:
   - Products: GET endpoints for retrieving products, filtering by category
   - Cart: Endpoints for managing cart items

2. **Storage Layer**:
   - Interface-driven design with `IStorage` providing the contract
   - Implementation using Drizzle ORM

3. **Schema**:
   - Users: Authentication and user management
   - Products: Product catalog with detailed information
   - Cart/CartItems: Shopping cart functionality

### Database

The application uses Drizzle ORM with a schema defined in `shared/schema.ts`, which includes:

1. **Users table**: For user authentication and profile information
2. **Products table**: For storing product information including:
   - Basic details (name, description, price)
   - Categorization (category, subcategory)
   - Product attributes (colors, sizes, stock)
   - Display flags (featured, new, trending, etc.)
3. **Carts and CartItems tables**: For managing user shopping carts

## Data Flow

1. **Product Browsing**:
   - User navigates to category/subcategory pages
   - Frontend makes API requests to fetch filtered products
   - Products are displayed with React Query handling caching

2. **Product Details**:
   - User clicks on a product to view details
   - Frontend requests specific product data by ID
   - User can select options (size, color) and add to cart

3. **Cart Management**:
   - Add to cart operations update local state via Context API
   - Cart data is persisted via API calls to the backend
   - Cart state is available throughout the application

4. **Checkout Flow** (appears to be in development):
   - Cart review
   - Order placement via API

## External Dependencies

### Frontend Libraries
- React for UI rendering
- Wouter for routing (lightweight alternative to React Router)
- React Query for data fetching and caching
- Radix UI for accessible UI primitives
- shadcn/ui for styled components
- Tailwind CSS for styling
- Lucide for icons

### Backend Libraries
- Express.js for API server
- Drizzle ORM for database operations
- Zod for schema validation
- Vite for development server and building

## Deployment Strategy

The application is configured for deployment on Replit with:

1. **Build Process**:
   - Frontend: Vite builds the React application
   - Backend: esbuild bundles the server code

2. **Runtime**:
   - Node.js environment
   - PostgreSQL database (configured in Replit)

3. **Environment Configuration**:
   - Development mode: Combined Vite dev server with API
   - Production mode: Static assets served by Express with API

4. **Database Setup**:
   - Drizzle handles migrations and schema updates
   - Connection configured via DATABASE_URL environment variable

## Getting Started

1. The application requires a PostgreSQL database to be provisioned
2. Environment variables:
   - `DATABASE_URL`: Connection string for PostgreSQL database
   - `NODE_ENV`: "development" or "production"

3. Development workflow:
   - `npm run dev`: Start development server
   - `npm run build`: Build for production
   - `npm run start`: Start production server
   - `npm run db:push`: Update database schema

## Current Status and Next Steps

The application has a well-structured foundation but appears to be in development:

1. **Implemented Features**:
   - Product browsing and filtering
   - Product detail views
   - Cart functionality
   - Responsive UI components

2. **To Be Implemented**:
   - User authentication flow
   - Checkout process
   - Order management
   - Admin dashboard

The database schema is defined but actual database implementation with PostgreSQL needs to be connected.